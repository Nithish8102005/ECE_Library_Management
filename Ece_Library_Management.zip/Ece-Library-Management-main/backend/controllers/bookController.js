const Book = require("../models/Book");
const XLSX = require("xlsx");

// @desc    Get all books
// @route   GET /api/books
// @access  Private
exports.getBooks = async (req, res) => {
  try {
    const {
      search,
      category,
      subCategory,
      author,
      publisher,
      yearFrom,
      yearTo,
      availability,
      sortBy,
      page = 1,
      limit = 20,
    } = req.query;

    // Build query
    let query = { isActive: true };

    // Search functionality
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: "i" } },
        { authors: { $regex: search, $options: "i" } },
        { isbn: { $regex: search, $options: "i" } },
      ];
    }

    if (category) {
      query.category = category;
    }

    if (subCategory) {
      query.subCategory = subCategory;
    }

    if (author) {
      query.authors = { $regex: author, $options: "i" };
    }

    if (publisher) {
      query.publisher = { $regex: publisher, $options: "i" };
    }

    if (yearFrom || yearTo) {
      query.yearOfPublication = {};
      if (yearFrom) query.yearOfPublication.$gte = parseInt(yearFrom);
      if (yearTo) query.yearOfPublication.$lte = parseInt(yearTo);
    }

    if (availability === "available") {
      query.availableCopies = { $gt: 0 };
    } else if (availability === "unavailable") {
      query.availableCopies = 0;
    }

    // Sorting
    let sort = {};
    if (sortBy) {
      switch (sortBy) {
        case "title":
          sort = { title: 1 };
          break;
        case "year":
          sort = { yearOfPublication: -1 };
          break;
        case "popular":
          sort = { issueCount: -1 };
          break;
        case "recent":
          sort = { addedAt: -1 };
          break;
        default:
          sort = { title: 1 };
      }
    } else {
      sort = { title: 1 };
    }

    // Pagination
    const skip = (page - 1) * limit;

    const books = await Book.find(query)
      .sort(sort)
      .limit(parseInt(limit))
      .skip(skip)
      .populate("addedBy", "name email");

    const total = await Book.countDocuments(query);

    res.status(200).json({
      success: true,
      count: books.length,
      total,
      pages: Math.ceil(total / limit),
      currentPage: parseInt(page),
      data: books,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// @desc    Get single book
// @route   GET /api/books/:id
// @access  Private
exports.getBook = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id).populate(
      "addedBy",
      "name email",
    );

    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    res.status(200).json({
      success: true,
      data: book,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// @desc    Create new book
// @route   POST /api/books
// @access  Private (Librarian only)
exports.createBook = async (req, res) => {
  try {
    req.body.addedBy = req.user.id;
    req.body.availableCopies = req.body.totalCopies;

    const book = await Book.create(req.body);

    res.status(201).json({
      success: true,
      data: book,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// @desc    Update book
// @route   PUT /api/books/:id
// @access  Private (Librarian only)
exports.updateBook = async (req, res) => {
  try {
    let book = await Book.findById(req.params.id);

    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    // If total copies are updated, adjust available copies
    if (req.body.totalCopies && req.body.totalCopies !== book.totalCopies) {
      const difference = req.body.totalCopies - book.totalCopies;
      req.body.availableCopies = book.availableCopies + difference;

      // Ensure available copies don't go negative
      if (req.body.availableCopies < 0) {
        req.body.availableCopies = 0;
      }
    }

    book = await Book.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.status(200).json({
      success: true,
      data: book,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// @desc    Delete book
// @route   DELETE /api/books/:id
// @access  Private (Librarian only)
exports.deleteBook = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);

    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    // Soft delete - mark as inactive
    book.isActive = false;
    await book.save();

    res.status(200).json({
      success: true,
      message: "Book deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// @desc    Download Excel template for bulk book upload
// @route   GET /api/books/template/download
// @access  Private (Librarian only)
exports.downloadTemplate = async (req, res) => {
  try {
    // Define template headers with sample data
    const templateData = [
      {
        Title: "Sample Book Title",
        "Authors (comma separated)": "John Doe, Jane Smith",
        Publisher: "Sample Publisher",
        "Year of Publication": 2024,
        Edition: "1st",
        ISBN: "978-0-123456-78-9",
        Category: "Analog Electronics",
        "Sub-Category": "General",
        "Total Copies": 5,
        "Shelf Location": "A-101",
        Description: "Brief description of the book",
      },
    ];

    // Add instruction rows
    const instructions = {
      Title: "INSTRUCTIONS: Fill in the book details below",
      "Authors (comma separated)": "Multiple authors separated by commas",
      Publisher: "Publisher name",
      "Year of Publication": "Four-digit year (e.g., 2024)",
      Edition: "Edition info (e.g., 1st, 2nd, 3rd)",
      ISBN: "ISBN-10 or ISBN-13",
      Category:
        "Choose from: Analog Electronics, Digital Electronics, Communication Systems, Signals and Systems, VLSI Design, Embedded Systems, Microprocessors & Microcontrollers, Antennas & RF Engineering, Control Systems, Internet of Things, JLPT N5, JLPT N4, JLPT N3",
      "Sub-Category":
        "Choose from: Vocabulary, Grammar, Kanji, Reading, Listening, General",
      "Total Copies": "Number of copies (minimum 1)",
      "Shelf Location": "Physical location in library",
      Description: "Optional description (can be left empty)",
    };

    // Create workbook
    const wb = XLSX.utils.book_new();

    // Create worksheet with instructions and sample data
    const ws = XLSX.utils.json_to_sheet([instructions, ...templateData]);

    // Set column widths
    const colWidths = [
      { wch: 30 }, // Title
      { wch: 30 }, // Authors
      { wch: 20 }, // Publisher
      { wch: 20 }, // Year
      { wch: 15 }, // Edition
      { wch: 20 }, // ISBN
      { wch: 25 }, // Category
      { wch: 15 }, // Sub-Category
      { wch: 15 }, // Total Copies
      { wch: 15 }, // Shelf Location
      { wch: 40 }, // Description
    ];
    ws["!cols"] = colWidths;

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, "Books Template");

    // Generate buffer
    const excelBuffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    // Set headers for file download
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=books_upload_template.xlsx",
    );

    // Send file
    res.send(excelBuffer);
  } catch (error) {
    console.error("Template download error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to generate template",
      error: error.message,
    });
  }
};

// @desc    Bulk upload books from Excel file
// @route   POST /api/books/bulk-upload
// @access  Private (Librarian only)
exports.bulkUploadBooks = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Please upload an Excel file",
      });
    }

    // Read the Excel file from buffer
    const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];

    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet);

    if (jsonData.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Excel file is empty",
      });
    }

    // Filter out instruction rows and validate data
    const validBooks = [];
    const errors = [];

    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i];
      const rowNumber = i + 2; // Excel rows start at 1, plus 1 for header

      // Skip instruction rows
      if (
        row.Title &&
        row.Title.toString().toUpperCase().includes("INSTRUCTION")
      ) {
        continue;
      }

      // Skip sample data rows
      if (row.Title && row.Title.toString().includes("Sample Book Title")) {
        continue;
      }

      // Validate required fields
      if (
        !row.Title ||
        !row["Authors (comma separated)"] ||
        !row.Publisher ||
        !row["Year of Publication"] ||
        !row.ISBN ||
        !row.Category ||
        !row["Total Copies"] ||
        !row["Shelf Location"]
      ) {
        errors.push({
          row: rowNumber,
          message: "Missing required fields",
          data: row,
        });
        continue;
      }

      // Validate category
      const validCategories = [
        "Analog Electronics",
        "Digital Electronics",
        "Communication Systems",
        "Signals and Systems",
        "VLSI Design",
        "Embedded Systems",
        "Microprocessors & Microcontrollers",
        "Antennas & RF Engineering",
        "Control Systems",
        "Internet of Things",
        "JLPT N5",
        "JLPT N4",
        "JLPT N3",
      ];

      if (!validCategories.includes(row.Category)) {
        errors.push({
          row: rowNumber,
          message: `Invalid category: ${row.Category}`,
          data: row,
        });
        continue;
      }

      // Validate sub-category
      const validSubCategories = [
        "Vocabulary",
        "Grammar",
        "Kanji",
        "Reading",
        "Listening",
        "General",
      ];
      const subCategory = row["Sub-Category"] || "General";

      if (!validSubCategories.includes(subCategory)) {
        errors.push({
          row: rowNumber,
          message: `Invalid sub-category: ${subCategory}`,
          data: row,
        });
        continue;
      }

      // Parse authors
      const authors = row["Authors (comma separated)"]
        .split(",")
        .map((a) => a.trim())
        .filter((a) => a);

      if (authors.length === 0) {
        errors.push({
          row: rowNumber,
          message: "At least one author is required",
          data: row,
        });
        continue;
      }

      // Validate year
      const year = parseInt(row["Year of Publication"]);
      if (isNaN(year) || year < 1900 || year > new Date().getFullYear()) {
        errors.push({
          row: rowNumber,
          message: `Invalid year: ${row["Year of Publication"]}`,
          data: row,
        });
        continue;
      }

      // Validate total copies
      const totalCopies = parseInt(row["Total Copies"]);
      if (isNaN(totalCopies) || totalCopies < 1) {
        errors.push({
          row: rowNumber,
          message: `Invalid total copies: ${row["Total Copies"]}`,
          data: row,
        });
        continue;
      }

      // Create book object
      const bookData = {
        title: row.Title.trim(),
        authors: authors,
        publisher: row.Publisher.trim(),
        yearOfPublication: year,
        edition: row.Edition ? row.Edition.toString().trim() : "1st",
        isbn: row.ISBN.toString().trim(),
        category: row.Category,
        subCategory: subCategory,
        totalCopies: totalCopies,
        availableCopies: totalCopies,
        shelfLocation: row["Shelf Location"].toString().trim(),
        description: row.Description ? row.Description.toString().trim() : "",
        addedBy: req.user.id,
      };

      validBooks.push({ row: rowNumber, data: bookData });
    }

    // If no valid books, return errors
    if (validBooks.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No valid books found in the Excel file",
        errors: errors,
      });
    }

    // Insert books into database
    const insertedBooks = [];
    const insertErrors = [];

    for (const { row, data } of validBooks) {
      try {
        const book = await Book.create(data);
        insertedBooks.push({ row, book });
      } catch (error) {
        insertErrors.push({
          row: row,
          message: error.message,
          data: data,
        });
      }
    }

    // Return results
    res.status(201).json({
      success: true,
      message: `Successfully uploaded ${insertedBooks.length} book(s)`,
      data: {
        inserted: insertedBooks.length,
        failed: insertErrors.length,
        validationErrors: errors.length,
        insertedBooks: insertedBooks.map((b) => ({
          title: b.book.title,
          isbn: b.book.isbn,
        })),
        errors: [...errors, ...insertErrors],
      },
    });
  } catch (error) {
    console.error("Bulk upload error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to process Excel file",
      error: error.message,
    });
  }
};

// @desc    Get book categories
// @route   GET /api/books/categories
// @access  Private
exports.getCategories = async (req, res) => {
  try {
    const categories = await Book.distinct("category");

    res.status(200).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

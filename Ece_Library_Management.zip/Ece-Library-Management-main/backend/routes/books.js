const express = require("express");
const router = express.Router();
const {
  getBooks,
  getBook,
  createBook,
  updateBook,
  deleteBook,
  getCategories,
  downloadTemplate,
  bulkUploadBooks,
} = require("../controllers/bookController");
const { protect } = require("../middleware/auth");
const { authorize } = require("../middleware/roleCheck");
const upload = require("../middleware/upload");

router
  .route("/")
  .get(protect, getBooks)
  .post(protect, authorize("librarian"), createBook);

router.get("/categories", protect, getCategories);

// Excel template download route
router.get(
  "/template/download",
  protect,
  authorize("librarian"),
  downloadTemplate,
);

// Bulk upload route
router.post(
  "/bulk-upload",
  protect,
  authorize("librarian"),
  upload.single("file"),
  bulkUploadBooks,
);

router
  .route("/:id")
  .get(protect, getBook)
  .put(protect, authorize("librarian"), updateBook)
  .delete(protect, authorize("librarian"), deleteBook);

module.exports = router;
